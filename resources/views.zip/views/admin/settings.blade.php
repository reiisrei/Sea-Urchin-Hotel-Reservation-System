@if(Auth::user()->name == 'admin')
@extends('admin.layouts.admin')
@section('content')
  <h1>Settings</h1>
  <hr>
  <h4 style="color:maroon">Rooms Information</h5>
  </br></br>
  <h5>Standard Room</h5>
  <hr>
  {!! Form::open(['action' => ['SettingsController@standard'],'method' => 'POST','enctype' => 'multipart/form-data']) !!}
  {{Form::text('title', $standard->title, [ 'placeholder' => 'Title', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('nightRate', $standard->nightRate, [ 'placeholder' => 'Night Rate', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('capacity', $standard->capacity, [ 'placeholder' => 'Capacity', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('childrenAllowed', $standard->childrenAllowed, [ 'placeholder' => 'Children Allowed', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('maxAdult', $standard->maxAdult, [ 'placeholder' => 'Max Adult', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('description', $standard->description, [ 'placeholder' => 'Description', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  {!! Form::close() !!}
  <h5>Photo:</h5>
  {!! Form::open(['action' => ['SettingsController@standardPhoto'],'method' => 'POST','enctype' => 'multipart/form-data']) !!}
  {{Form::file('cover_image')}}
  {{ Form::hidden('_method','PUT') }}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  {!! Form::close() !!}
  <hr>
  <h5>Quad Room</h5>
  <hr>
  {!! Form::open(['action' => ['SettingsController@quad'],'method' => 'POST','enctype' => 'multipart/form-data']) !!}
  {{Form::text('title', $quad->title, [ 'placeholder' => 'Title', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('nightRate', $quad->nightRate, [ 'placeholder' => 'Night Rate', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('capacity', $quad->capacity, [ 'placeholder' => 'Capacity', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('childrenAllowed', $quad->childrenAllowed, [ 'placeholder' => 'Children Allowed', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('maxAdult', $quad->maxAdult, [ 'placeholder' => 'Max Adult', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('description', $quad->description, [ 'placeholder' => 'Description', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::file('cover_image')}}
  {{ Form::hidden('_method','PUT') }}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  {!! Form::close() !!}
  <hr>
  <h5>Family Room</h5>
  <hr>
  {!! Form::open(['action' => ['SettingsController@family'],'method' => 'POST','enctype' => 'multipart/form-data']) !!}
  {{Form::text('title', $family->title, [ 'placeholder' => 'Title', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('nightRate', $family->nightRate, [ 'placeholder' => 'Night Rate', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('capacity', $family->capacity, [ 'placeholder' => 'Capacity', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('childrenAllowed', $family->childrenAllowed, [ 'placeholder' => 'Children Allowed', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('maxAdult', $family->maxAdult, [ 'placeholder' => 'Max Adult', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('description', $family->description, [ 'placeholder' => 'Description', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::file('cover_image')}}
  {{ Form::hidden('_method','PUT') }}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  {!! Form::close() !!}
  <hr>
  <h5>Barkada's Room</h5>
  <hr>
  {!! Form::open(['action' => ['SettingsController@barkada'],'method' => 'POST','enctype' => 'multipart/form-data']) !!}
  {{Form::text('title', $barkada->title, [ 'placeholder' => 'Title', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('nightRate', $barkada->nightRate, [ 'placeholder' => 'Night Rate', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('capacity', $barkada->capacity, [ 'placeholder' => 'Capacity', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('childrenAllowed', $barkada->childrenAllowed, [ 'placeholder' => 'Children Allowed', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('maxAdult', $barkada->maxAdult, [ 'placeholder' => 'Max Adult', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::text('description', $barkada->description, [ 'placeholder' => 'Description', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::file('cover_image')}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  {!! Form::close() !!}
  <hr>
  </br></br>
  <h4 style="color:maroon">Hotel Information</h5>
  </br>
    <hr>
  <h5>Phone Number</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
  {{Form::text('phone', '', [ 'placeholder' => 'Phone Number', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
  <h5>Email Address</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
  {{Form::text('email', '', [ 'placeholder' => 'Email Address', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
  <h5>Address</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
  {{Form::text('address', '', [ 'placeholder' => 'Address', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
  <h5>About Us</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
  {{Form::textarea('about', '', [ 'placeholder' => 'About Us', 'autofocus' , 'tabindex' => '1'])}}<br>
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
</br></br>
<h4 style="color:maroon">Social Media Links</h5>
</br>
  <hr>
  <h5>Facebook</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
  {{Form::text('facebook', '', [ 'placeholder' => 'Facebook', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
  <h5>Twitter</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
  {{Form::text('twitter', '', [ 'placeholder' => 'Twitter', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
  <h5>Instagram</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
  {{Form::text('instagram', '', [ 'placeholder' => 'Instagram', 'autofocus' , 'tabindex' => '1'])}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
</br></br>
<h4 style="color:maroon">Pictures</h5>
</br>
  <hr>
  <h5>Logo(header)</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
    {{Form::file('cover_image')}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
  <h5>Logo(footer)</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
    {{Form::file('cover_image')}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
  <h5>Homepage slider(2 pictures)</h5>
  {!! Form::open(['url' => '/create/post','enctype' => 'multipart/form-data']) !!}
    {{Form::file('cover_image')}}
    {{Form::file('cover_image')}}
  {{Form::submit('Update', ['class'=> 'btn btn-primary btn-sm', 'tabindex' => '2'])}}
  <hr>
@endsection
@else
  @section('content')
    <h1><strong>You are not authorized to view this page.</strong></h1>
    <a class="btn btn-danger btn-xl" href="/dashboard"><i class="fa fa-backspace"></i> Go back!</a>
  @endsection

@endif
