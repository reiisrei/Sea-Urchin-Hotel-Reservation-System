<footer class="footer text-center fixed">
  <p>Copyright &copy; Sea Urchin Hotel 2018</p>
</footer>
