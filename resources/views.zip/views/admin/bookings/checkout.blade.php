@extends('admin.layouts.admin')

@section('content')
  <h1>Check Out Form</h1>
  <hr>
<div class="container center">
@if(session('success'))
  <div class="alert alert-success text-center">
    {{session('success')}}
  </div>
@endif
</div>
{!! Form::open(['action' => ['BookingController@checkout', $bookingDetail->bookingID],'method' => 'POST','enctype' => 'multipart/form-data']) !!}
<div class="container">
    <div class="row">
        <div class="col-lg">
            <p class="lead text-left">Name: {{ $bookingDetail->client->fullNmae }}</p>
            <p class="lead text-left">Phone Number: {{ $bookingDetail->client->phoneNumber }}</p>
            <p class="lead text-left">Email: {{ $bookingDetail->client->emailAddress }}</p>
            <p class="lead text-left">Check In Date: {{ $bookingDetail->checkInDate }}<u></u></p>
            <p class="lead text-left">Check Out Date: {{ $bookingDetail->checkOutDate }}<u></u></p>
            <p class="lead text-left">Number Of Rooms: {{ $bookingDetail->roomsCount }}</p>
            <p class="lead text-left">Number Of Nights: {{ $bookingDetail->numNights }}</p>
            <p class="lead text-left">Number Of Adults: {{ $bookingDetail->adultsCount }}</p>
            <p class="lead text-left">Number Of Children: {{ $bookingDetail->childrenCount }}</p>
            <p class="lead text-left">Extra: {{ $bookingDetail->amenities->title }}</p>
        </div>
        <div class="col-lg">
            <p class="lead text-left">Room Type: {{ $bookingDetail->roomType->title }}</p>
            <p class="lead text-left">Total Room Price: &#8369; {{ number_format($totalRoomPrice,2) }}</p>
            <p class="lead text-left">Amenities Price: &#8369; {{ number_format($bookingDetail->amenities->amount,2) }}</p>
            <p class="lead text-left">Total: &#8369; <span style="color:green"><strong>{{ number_format($total,2) }}</strong></span><b></b></p>
            <p class="lead text-left">Downpayment: &#8369; <span style="color:red"><strong>{{ number_format($bookingDetail->payment->ammountPaid,2) }}</strong></span><b></b></p>
            <p class="lead text-left">Damages: &#8369; <span style="color:green"><strong>{{ number_format($bookingDetail->payment->damages,2) }}</strong></span><b></b></p>
            <p class="lead text-left">Additional Charge: &#8369; <span style="color:green"><strong>{{--{{ number_format($bookingDetail->payment->damages,2) }}--}}</strong></span><b></b></p>
            <p class="lead text-left">Discount: &#8369; <span style="color:red"><strong>{{ number_format($discount,2) }} ({{ $bookingDetail->payment->discount }} %)</strong></span><b></b></p>
            <p class="lead text-left">Balance: &#8369; <span style="color:green"><strong>{{ number_format((($total - $discount) - $bookingDetail->payment->ammountPaid) + $bookingDetail->payment->damages,2) }}</strong></span><b></b></p>


            <p class="lead text-left">Payment ID: <a href="/managepayments/{{ $bookingDetail->payment->paymentID }}">{{ $bookingDetail->payment->paymentID }}</a></b></p>

            <p class="lead text-left"><strong>Status: <span style="color:red;">{{ $reservationDetail->status }}</span></strong></b></p>
            @if ($reservationDetail->status == 'Canceled' or $reservationDetail->status == 'Rebooking Requested')
                  <p class="lead text-left">Reason: {{ $reservationDetail->comment }}</b></p>
            @endif

        </div>
        <div class="col-lg">

          <div class="container forms">
              <div class="row"></br></br>
                <div class="col-xs-12 col-sm-6 col-md-6">
                  <div class="form-group">
                    {{ Form::label('total', 'Total: ',['style' => 'color:black']) }}
                    {{Form::text('total', number_format($total,2), ['class' => 'form-control input-lg', 'placeholder' => 'Total', 'autofocus' , 'tabindex' => '1' ])}}
                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6">
                  <div class="form-group">
                    {{ Form::label('balance', 'Balance: ',['style' => 'color:black']) }}
                     {{Form::text('balance', number_format((($total - $discount) - $bookingDetail->payment->ammountPaid) + $bookingDetail->payment->damages,2), ['class' => 'form-control input-lg', 'placeholder' => 'Amenities Price', 'autofocus' , 'tabindex' => '2'])}}
                  </div>
                </div>
              </div>
              <div class="form-group">
                  {{ Form::hidden('_method','PUT') }}
                {{Form::submit('Check Out', ['class'=> 'btn btn-primary py-3 px-5', 'tabindex' => '4'])}}
              </div>
                  {!! Form::close() !!}
          </div>

        </div>
    </div>
</div>

@endsection
