@extends('admin.layouts.admin')

@section('content')
<a href="/bookings" class="btn btn-primary"><i class="fa fa-backspace"></i> Back</a>
<div class="container">
    <div class="row">
        <div class="col-lg">
            <p class="lead text-left">Name: {{ $booking->client->fullNmae }}</p>
            <p class="lead text-left">Phone Number: {{ $booking->client->phoneNumber }}</p>
            <p class="lead text-left">Email: {{ $booking->client->emailAddress }}</p>
            <p class="lead text-left">Check In Date: {{ $booking->checkInDate }}<u></u></p>
            <p class="lead text-left">Check Out Date: {{ $booking->checkOutDate }}<u></u></p>
            <p class="lead text-left">Number Of Rooms: {{ $booking->roomsCount }}</p>
            <p class="lead text-left">Number Of Nights: {{ $booking->numNights }}</p>
            <p class="lead text-left">Number Of Adults: {{ $booking->adultsCount }}</p>
            <p class="lead text-left">Number Of Children: {{ $booking->childrenCount }}</p>
            <p class="lead text-left">Extra: {{ $booking->amenities->title }}</p>
        </div>
        <div class="col-lg">
            <p class="lead text-left">Room Type: {{ $booking->roomType->title }}</p>
            <p class="lead text-left">Total Room Price: &#8369; {{ number_format($totalRoomPrice,2) }}</p>
            <p class="lead text-left">Amenities Price: &#8369; {{ number_format($booking->amenities->amount,2) }}</p>
            <p class="lead text-left">Total: &#8369; <span style="color:green"><strong>{{ number_format($total,2) }}</strong></span><b></b></p>
            <p class="lead text-left">Downpayment: &#8369; <span style="color:red"><strong>{{ number_format($booking->payment->ammountPaid,2) }}</strong></span><b></b></p>
            <p class="lead text-left">Damages: &#8369; <span style="color:green"><strong>{{ number_format($booking->payment->damages,2) }}</strong></span><b></b></p>
            <p class="lead text-left">Additional Charge: &#8369; <span style="color:green"><strong>{{--{{ number_format($booking->payment->damages,2) }}--}}</strong></span><b></b></p>
            <p class="lead text-left">Discount: &#8369; <span style="color:red"><strong>{{ number_format($discount,2) }} ({{ $booking->payment->discount }} %)</strong></span><b></b></p>
            <p class="lead text-left">Balance: &#8369; <span style="color:green"><strong>{{ number_format((($total - $discount) - $booking->payment->ammountPaid) + $booking->payment->damages,2) }}</strong></span><b></b></p>

            <p class="lead text-left">Payment Method: {{ $booking->payment->paymentMethod }}</b></p>

            <p class="lead text-left">Payment ID: <a href="/managepayments/{{ $booking->payment->paymentID }}">{{ $booking->payment->paymentID }}</a></b></p>

            <p class="lead text-left"><strong>Status: <span style="color:red;">{{ $reservationDetail->status }}</span></strong></b></p>
            @if ($reservationDetail->status == 'Canceled' or $reservationDetail->status == 'Rebooking Requested')
                  <p class="lead text-left">Reason: {{ $reservationDetail->comment }}</b></p>
            @endif

        </div>
        <div class="col-lg">
        @if ($reservationDetail->status == 'Checked-In')
          {!! Form::open(['action' => ['BookingController@updatePrice', $booking->bookingID],'method' => 'POST','enctype' => 'multipart/form-data']) !!}
            <h3>Additional Charge</h3>
            <div class="container forms">
                <div class="row"></br></br>
                  <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="form-group">
                      {{ Form::label('bedsheet', 'Bed sheet: ',['style' => 'color:black']) }}
                      {{Form::text('bedsheet', '', ['class' => 'form-control input-lg', 'placeholder' => 'Bed sheet', 'autofocus' , 'tabindex' => '1' ])}}
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="form-group">
                      {{ Form::label('pillow', 'Pillow: ',['style' => 'color:black']) }}
                       {{Form::text('pillow', '', ['class' => 'form-control input-lg', 'placeholder' => 'Pillow', 'autofocus' , 'tabindex' => '2'])}}
                    </div>
                  </div>
                  <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="form-group">
                      {{ Form::label('towel', 'Towel: ',['style' => 'color:black']) }}
                       {{Form::text('towel', '', ['class' => 'form-control input-lg', 'placeholder' => 'Towel', 'autofocus' , 'tabindex' => '3'])}}
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  {{ Form::label('damages', 'Damages: ',['style' => 'color:black']) }}
                  {{Form::text('damages', '', ['class' => 'form-control input-lg', 'placeholder' => 'Damages', 'autofocus' , 'tabindex' => '4'])}}</br>
                </div>
                <div class="form-group">
                  {{ Form::label('discount', 'Discount: ',['style' => 'color:black']) }}
                  {{Form::text('discount', '', ['class' => 'form-control input-lg', 'placeholder' => 'Discount', 'autofocus' , 'tabindex' => '5'])}}</br>
                </div>
                <div class="form-group">
                    {{ Form::hidden('_method','PUT') }}
                  {{Form::submit('Update', ['class'=> 'btn btn-primary py-3 px-5', 'tabindex' => '6'])}}
                </div>
                    {!! Form::close() !!}
            </div>
        @endif
      </div>
    </div>
</div>
@endsection
