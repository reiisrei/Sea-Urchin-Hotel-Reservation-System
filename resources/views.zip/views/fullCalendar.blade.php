@extends('layouts.app')
@section('content')

<link href="{{ URL::asset('hello-week-master/distdist/helloweek.css')}}" rel="stylesheet">
<script src="{{ URL::asset('hello-week-master/distdist/helloweek.min.js')}}"></script>
<script type="text/javascript">
const myCalendar = new HelloWeek();
const next = document.querySelector('.demo-next');
const prev = document.querySelector('.demo-prev');

</script>
<div class="hello-week">
  <div class="hello-week__header">
    <button class="btn demo-prev"><img draggable="false" class="emoji" alt="◀" src="https://s.w.org/images/core/emoji/11/svg/25c0.svg"></button>
    <div class="hello-week__label"></div>
    <button class="btn demo-next"><img draggable="false" class="emoji" alt="▶" src="https://s.w.org/images/core/emoji/11/svg/25b6.svg"></button>
  </div>
  <div class="hello-week__week"></div>
  <div class="hello-week__month"></div>
</div>

@endsection
