@extends('layouts.404head')

@section('content')
  <div class="content"><!-- Content Section -->
		<div class="container">
			<div class="row">
				<div class="error-page-container pos-center"> <!-- 404 Page -->
					<h2>THIS PAGE DOES NOT EXIST</h2>
					<div class="big-error-number margint80 marginb80">404</div>
					<div class="button-style-1"><h6><a href="/">HOMEPAGE</a></h6></div>
				</div>
			</div>
		</div>
	</div>
@endsection
