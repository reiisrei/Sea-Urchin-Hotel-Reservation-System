@extends('layouts.app')

@section('content')
<div class="breadcrumb breadcrumb-1 pos-center">
    <h1>Booking Detail - {{ $bookingDetail->bookingID }}</h1>
</div>
</br></br>
<div class="pos-center marginb20">
    <h2>Booking Detail</h2>
    <img src="theme/img/shape.png">
</div>
<div class="container">
    <div class="col-lg-12 clearfix margint40 room-single-tab">
        <!-- Room Tab -->
        <div class="tab-style-1 ">
            <ul class="tabbed-area tab-style-nav clearfix">
                @if ($reservationDetail->status == 'Canceled' or $reservationDetail->status == 'Checked-In' or $reservationDetail->status == 'Checked-Out')
                <li class="active">
                    <h6><a href="#tab1s">Booking Summary</a></h6>
                </li>
                @else
                <li class="active">
                    <h6><a href="#tab1s">Booking Summary</a></h6>
                </li>
                <li class="">
                    <h6><a href="#tab2s">Cancellation</a></h6>
                </li>
                <li class="">
                    <h6><a href="#tab3s">Rebooking</a></h6>
                </li>
                @endif

            </ul>
            <div class="tab-content tab-style-content">
                <div class="tab-pane fade active in" id="tab1s">
                    <div class="col-lg-12 margint30">
                        <div class=" text-center ">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <p class="lead text-left">Name: {{ $bookingDetail->client->fullNmae }}</p>
                                        <p class="lead text-left">Phone Number: {{ $bookingDetail->client->phoneNumber }}</p>
                                        <p class="lead text-left">Email: {{ $bookingDetail->client->emailAddress }}</p>
                                        <p class="lead text-left">Check In Date: {{ $bookingDetail->checkInDate }}<u></u></p>
                                        <p class="lead text-left">Check Out Date: {{ $bookingDetail->checkOutDate }}<u></u></p>
                                        <p class="lead text-left">Number Of Rooms: {{ $bookingDetail->roomsCount }}</p>
                                        <p class="lead text-left">Number Of Nights: {{ $bookingDetail->numNights }}</p>
                                        <p class="lead text-left">Number Of Adults: {{ $bookingDetail->adultsCount }}</p>
                                        <p class="lead text-left">Number Of Children: {{ $bookingDetail->childrenCount }}</p>
                                        <p class="lead text-left">Extra: {{ $bookingDetail->amenities->title }}</p>
                                    </div>
                                    <div class="col-lg-4">
                                        <p class="lead text-left">Room Type: {{ $bookingDetail->roomType->title }}</p>
                                        <p class="lead text-left">Total Room Price: {{ number_format($totalRoomPrice,2) }}</p>
                                        <p class="lead text-left">Amenities Price: {{ number_format($bookingDetail->amenities->amount,2) }}</p>
                                        <p class="lead text-left">Total: {{ number_format($total,2) }}<b></b></p>
                                        <p class="lead text-left">Downpayment: {{ number_format($downpayment,2) }}<b></b></p>
                                        <p class="lead text-left">Please pay before: {{ date('m-d-Y', strtotime($bookingDetail->bookExpire)) }}</b></p>
                                        <p class="lead text-left">Payment Method: {{ $bookingDetail->payment->paymentMethod }}</b></p>

                                        <p class="lead text-left"><strong>Status: <span style="color:red;">{{ $reservationDetail->status }}</span></strong></b></p>

                                        <div class="module module-multi module-series inset pull-left">
                                            <div class="module-title">
                                                <div class="title-inner">
                                                    <span class="span-0">Important</span>
                                                    <span class="span-1">&nbsp;Reminders</span>
                                                </div>
                                            </div>
                                            <div class="module-body">
                                                <div class="module-body-wrap">
                                                    <div class="fragment-media  module-member">
                                                        <div class="media-body-wrap">
                                                            <div class="media-title">
                                                                Pay the total amount to avoid cancellation.
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="fragment-media  module-member">
                                                        <div class="media-body-wrap">
                                                            <div class="media-title">
                                                                Pay exactly the total amount,
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="fragment-media  module-member">
                                                        <div class="media-body-wrap">
                                                            <div class="media-title">
                                                                excess will not be refunded.
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="series-footer">
                                                &nbsp;
                                            </div>
                                        </div>
                                        @if (is_null($bookingDetail->payment->datePaid))
                                        {!! Form::open(['url' => '/payment']) !!}
                                        </br></br>{{Form::submit('Pay Now', ['class'=> 'btn btn-danger float-left'])}}
                                        {!! Form::close() !!}
                                        @endif

                                    </div>
                                    <div class="col-lg-4 col-sm-6 clearfix pull-left">
                                        <div class="home-room-box clearfix">
                                            <div class="room-image">
                                                <img alt="Room Images" class="img-responsive" src="/storage/cover_images/{{ $bookingDetail->roomType->cover_image }}">
                                                <div class="home-room-details">
                                                    <h5><span class="pull-left">{{ $bookingDetail->roomType->title }}</span><strong class="pull-right">Good for {{ $bookingDetail->roomType->capacity}} Person</strong></h5>
                                                    <div class="pull-left">
                                                        <ul>
                                                            <li title="Free Wifi"><i class="fa fa-wifi"></i></li>
                                                            <li title="Parking Space"><i class="fa fa-car"></i></li>
                                                            <li title="Airconditioned Room"><i class="fa fa-snowflake-o"></i></li>
                                                            <li title="Televisions"><i class="fa fa-television"></i></li>
                                                            <li title="Shower"><i class="fa fa-shower"></i></li>
                                                            <li title="Breakfast"><i class="fa fa-spoon"></i></li>
                                                        </ul>
                                                    </div>
                                                    <div class="pull-right room-rating">
                                                        <ul>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star inactive"></i></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="room-details">
                                                <p>{{ $bookingDetail->roomType->description }}</p>
                                            </div>
                                            <div class="room-bottom">
                                                <div class="pull-left">
                                                    <h4>{{number_format( $bookingDetail->roomType->nightRate )}}<span class="room-bottom-time">/ Day</span></h4>
                                                </div>
                                                <div class="pull-right">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="tab2s">
                    <div class="col-lg-4 margint30">
                        <div class="module module-multi module-series inset pull-left">
                            <div class="module-title">
                                <div class="title-inner">
                                    <span class="span-0">Important</span>
                                    <span class="span-1">&nbsp;Reminders</span>
                                </div>
                            </div>
                            <div class="module-body">
                                <div class="module-body-wrap">
                                    <div class="fragment-media  module-member">
                                        <div class="media-body-wrap">
                                            <div class="media-title">
                                                Pay the total amount to avoid cancellation.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fragment-media  module-member">
                                        <div class="media-body-wrap">
                                            <div class="media-title">
                                                Pay exactly the total amount,
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fragment-media  module-member">
                                        <div class="media-body-wrap">
                                            <div class="media-title">
                                                excess will not be refunded.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="series-footer">
                                &nbsp;
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 margint30 pull-right">
                        <h5><strong style="color:red">Cancellation Policy</strong></br></h5>
                        <p>Cancelling your reservation before { Date here } will result in no charge. Canceling your reservation after {Date here} or failing to show, will result in a charge of { $ } Failing to call or show before the check-out time
                            after the first night of a reservation will result in cancellation of the remainder of your reservation.</p></br>
                        <strong>Reason (Optional)</strong></br>

                        {!! Form::open(['url' => '/detail/cancel','enctype' => 'multipart/form-data']) !!}
                        {{Form::textarea('comment', '', ['class' => 'form-control', 'placeholder' => 'Your message here...', 'cols' => '30', 'rows' => '7', 'maxlength' => '2500'])}}
                        </br></br>{{Form::submit('Cancel Booking', ['class'=> 'btn btn-primary py-3 px-5','onclick' => 'return confirm("Canceling a booking is non refundable. Are you sure you want to continue?")'])}}
                        {!! Form::close() !!}

                    </div>
                </div>
                <div class="tab-pane fade" id="tab3s">
                    <div class="col-lg-4 margint30">
                        <div class="module module-multi module-series inset pull-left">
                            <div class="module-title">
                                <div class="title-inner">
                                    <span class="span-0">Important</span>
                                    <span class="span-1">&nbsp;Reminders</span>
                                </div>
                            </div>
                            <div class="module-body">
                                <div class="module-body-wrap">
                                    <div class="fragment-media  module-member">
                                        <div class="media-body-wrap">
                                            <div class="media-title">
                                                Pay the total amount to avoid cancellation.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fragment-media  module-member">
                                        <div class="media-body-wrap">
                                            <div class="media-title">
                                                Pay exactly the total amount,
                                            </div>
                                        </div>
                                    </div>
                                    <div class="fragment-media  module-member">
                                        <div class="media-body-wrap">
                                            <div class="media-title">
                                                excess will not be refunded.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="series-footer">
                                &nbsp;
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 margint30 pull-right">
                        <h5><strong style="color:red">Rebooking Policy</strong></h5>
                        <p>Rebooking your reservation before { Date here } will result in no charge. Rebooking your reservation after {Date here} or failing to show, will result in a charge of { $ } Failing to call or show before the check-out time
                            after the first night of a reservation will result in Rebooking of the remainder of your reservation.</p>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    {{ Form::label('checkin', 'Check In Date: ',['style' => 'color:black']) }}
                                    {{ Form::text('checkindate', '' , ['id' => 'dpd1', 'placeholder' => 'Check In Date' , 'required', 'class' => 'form-control input-lg', 'tabindex' => '5']) }}
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    {{ Form::label('checkout', 'Check Out Date: ',['style' => 'color:black']) }}
                                    {{ Form::text('checkoutdate', '', ['id' => 'dpd2', 'placeholder' => 'Check Out Date' , 'required', 'class' => 'form-control input-lg', 'tabindex' => '6']) }}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    {{ Form::label('rooms', 'Number of Rooms: ',['style' => 'color:black']) }}
                                    {{ Form::select('n_rooms', array('1' => '1', '2' => '2', '3' => '3', '4' => '4+'), null, ['class' => 'form-control input-lg','placeholder' => 'Select Number Of Rooms', 'required', 'tabindex' => '7']) }}
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    {{ Form::label('rooms', 'Room Type: ',['style' => 'color:black']) }}
                                    {{ Form::select('room_type', array('1' => 'Standard Room', '2' => 'Quad Room', '3' => 'Family Room', '4' => 'Barkada Room'), null, ['class' => 'form-control input-lg','placeholder' => 'Select Room Type', 'required', 'tabindex' => '8']) }}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    {{ Form::label('adult', 'Number of Adult: ',['style' => 'color:black']) }}
                                    {{ Form::select('n_adult', array('1' => '1', '2' => '2', '3' => '3', '4' => '4+'), null, ['class' => 'form-control input-lg','placeholder' => 'Select Number of Adults', 'required', 'tabindex' => '9']) }}
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    {{ Form::label('children', 'Number of Children: ',['style' => 'color:black']) }}
                                    {{ Form::select('n_children', array('0' => '0','1' => '1', '2' => '2', '3' => '3', '4' => '4+'), null, ['class' => 'form-control input-lg','placeholder' => 'Select Number of Children', 'required', 'tabindex' => '10']) }}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    {{ Form::label('extra', 'Extra: ',['style' => 'color:black']) }}
                                    {{ Form::select('amenities', array('1' => 'Swimming Gear', '2' => 'Hundred Island Tour', '3' => 'Boat Rental'), null, ['class' => 'form-control input-lg','placeholder' => 'None', 'tabindex' => '11']) }}
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">

                                </div>
                            </div>
                        </div>
                        </br><strong>Reason (Optional)</strong></br>
                        {!! Form::open(['url' => '/payment']) !!}
                        {{Form::textarea('reason', '', ['class' => 'form-control', 'placeholder' => 'Your message here...', 'cols' => '30', 'rows' => '7', 'maxlength' => '2500'])}}
                        </br></br>{{Form::submit('Rebooking', ['class'=> 'btn btn-danger float-left'])}}
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
